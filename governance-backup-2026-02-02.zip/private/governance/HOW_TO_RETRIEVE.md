# How to Retrieve and Verify EA-GOV-PP-001

## Your Files (keep these together ALWAYS)

```
private/governance/
├── EA-GOV-PP-001.md        ← Your protected document
├── EA-GOV-PP-001.md.ots    ← Blockchain proof (NEVER delete)
├── EA-GOV-PP-001.sha256    ← Hash backup
└── HOW_TO_RETRIEVE.md      ← This guide
```

---

## Step 1: Find Your Files

Your document is stored in:
```
/workspaces/WellFit-Community-Daily-Complete/private/governance/
```

This folder is GITIGNORED — it stays on your local machine only.

---

## Step 2: Install Verification Tool (if needed)

```bash
pip install opentimestamps-client
```

---

## Step 3: Verify the Blockchain Timestamp

```bash
cd /workspaces/WellFit-Community-Daily-Complete/private/governance
ots verify EA-GOV-PP-001.md.ots
```

**Expected output (after confirmation):**
```
Success! Bitcoin block XXXXXX attests document existed as of 2026-02-01
```

---

## Step 4: Verify the Hash Manually (optional)

```bash
cd /workspaces/WellFit-Community-Daily-Complete/private/governance
sha256sum EA-GOV-PP-001.md
```

**Must match:** `85620a35aebcb1c58a7667c7052afee8e3304b73dba11e692a9899897eafecc0`

(Note: This is the hash OF the signed document. The original unsigned document hash was `13b9e483...`)

---

## If You Lose Access to This Codespace

Your proof still exists in THREE places:

1. **GitHub** (public attestation only, not the document):
   ```
   docs/governance/IP_ATTESTATIONS.md
   ```
   Contains the hash: `13b9e483b874d7a5fa38d3ecd4d83d0755d476ba9fa1de06dd54a35d5b405081`

2. **Bitcoin Blockchain** (permanent, immutable):
   - Your `.ots` file references this
   - Can be verified from any computer with `opentimestamps-client`

3. **Git History** (commit `8e89fbb6` on 2026-02-01):
   ```bash
   git log --grep="EA-GOV-PP-001"
   ```

---

## CRITICAL: Backup These Files

Copy these files to a safe location outside this codespace:

```bash
# Copy to your local machine or cloud storage:
private/governance/EA-GOV-PP-001.md
private/governance/EA-GOV-PP-001.md.ots
```

**Suggested backup locations:**
- Encrypted USB drive
- Password manager secure notes
- Private cloud storage (not shared)

---

## Summary

| What | Where | Purpose |
|------|-------|---------|
| Document | `private/governance/EA-GOV-PP-001.md` | Your IP |
| Blockchain proof | `private/governance/EA-GOV-PP-001.md.ots` | Proves date |
| Public attestation | `docs/governance/IP_ATTESTATIONS.md` | Hash-only record |
| Git commit | `8e89fbb6` | Timestamp backup |

---

## Emergency Contacts

If you need to prove ownership in a legal dispute:
1. Show the `.ots` file + document
2. Run `ots verify` in front of the other party
3. The Bitcoin blockchain confirms the date — this is court-admissible

---

*Created: 2026-02-01*
*Document ID: EA-GOV-PP-001*
