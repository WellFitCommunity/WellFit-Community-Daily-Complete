// src/components/UploadMeal.tsx
import React, { useState } from 'react';
import { useSupabaseClient } from '@supabase/auth-helpers-react';

const UploadMeal: React.FC = () => {
  const supabase = useSupabaseClient();

  const [formData, setFormData] = useState({
    name: '',
    imageFile: null as File | null,
    ingredients: '',
    steps: '',
    calories: '',
    cost: '',
    cookTime: '',
    cookTemp: '',
    tags: ''
  });

  const [message, setMessage] = useState('');

  const handleUpload = async () => {
    setMessage('');
    if (!formData.name || !formData.ingredients || !formData.steps) {
      setMessage('Please fill in required fields: name, ingredients, and steps.');
      return;
    }

    try {
      let imageUrl = '';
      if (formData.imageFile) {
        const { data, error: uploadError } = await supabase.storage
          .from('meal_images')
          .upload(`meal-${Date.now()}`, formData.imageFile);
        if (uploadError) throw uploadError;

        const { publicUrl } = supabase.storage
          .from('meal_images')
          .getPublicUrl(data.path).data;
        imageUrl = publicUrl;
      }

      const { error: insertError } = await supabase.from('meals').insert({
        name: formData.name,
        image_url: imageUrl,
        ingredients: formData.ingredients.split('\n'),
        steps: formData.steps.split('\n'),
        calories: Number(formData.calories) || null,
        cost: formData.cost,
        cook_time: formData.cookTime,
        cook_temp: formData.cookTemp,
        tags: formData.tags ? formData.tags.split(',').map(tag => tag.trim()) : [],
        created_at: new Date().toISOString()
      });

      if (insertError) throw insertError;

      setMessage('✅ Meal uploaded successfully!');
      setFormData({
        name: '',
        imageFile: null,
        ingredients: '',
        steps: '',
        calories: '',
        cost: '',
        cookTime: '',
        cookTemp: '',
        tags: ''
      });
    } catch (err: any) {
      console.error(err);
      setMessage(`❌ Error: ${err.message}`);
    }
  };

  return (
    <div>
      <h2>Upload Meal</h2>
      {message && <div>{message}</div>}
      <form
        onSubmit={e => {
          e.preventDefault();
          handleUpload();
        }}
      >
        <input
          type="text"
          placeholder="Meal Name"
          value={formData.name}
          onChange={e => setFormData({ ...formData, name: e.target.value })}
          required
        />
        <input
          type="file"
          accept="image/*"
          onChange={e =>
            setFormData({
              ...formData,
              imageFile: e.target.files ? e.target.files[0] : null
            })
          }
        />
        <textarea
          placeholder="Ingredients (one per line)"
          value={formData.ingredients}
          onChange={e => setFormData({ ...formData, ingredients: e.target.value })}
          required
        />
        <textarea
          placeholder="Steps (one per line)"
          value={formData.steps}
          onChange={e => setFormData({ ...formData, steps: e.target.value })}
          required
        />
        <input
          type="number"
          placeholder="Calories"
          value={formData.calories}
          onChange={e => setFormData({ ...formData, calories: e.target.value })}
        />
        <input
          type="text"
          placeholder="Cost"
          value={formData.cost}
          onChange={e => setFormData({ ...formData, cost: e.target.value })}
        />
        <input
          type="text"
          placeholder="Cook Time"
          value={formData.cookTime}
          onChange={e => setFormData({ ...formData, cookTime: e.target.value })}
        />
        <input
          type="text"
          placeholder="Cook Temp"
          value={formData.cookTemp}
          onChange={e => setFormData({ ...formData, cookTemp: e.target.value })}
        />
        <input
          type="text"
          placeholder="Tags (comma separated)"
          value={formData.tags}
          onChange={e => setFormData({ ...formData, tags: e.target.value })}
        />
        <button type="submit">Upload Meal</button>
      </form>
    </div>
  );
};

export default UploadMeal;

