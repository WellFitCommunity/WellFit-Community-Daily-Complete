// src/data/types.ts

export interface Recipe {
    name: string;
    images: string[];
    ingredients: string[];
    steps: string[];
  }
  